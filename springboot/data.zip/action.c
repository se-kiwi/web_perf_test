Action()
{

	web_url("localhost:30701", 
		"URL=http://localhost:30701/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=/hello?username=test1&code=1bc460df-7c8f-44a5-954a-7a0a6816027d", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(7);

	web_submit_data("login", 
		"Action=http://localhost:30701/login", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://localhost:30701/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=test1", ENDITEM, 
		"Name=password", "Value=test1", ENDITEM, 
		LAST);

	return 0;
}